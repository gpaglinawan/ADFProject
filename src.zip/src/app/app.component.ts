import { Component,NgModule } from '@angular/core';
import { customers } from './customers';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import {DomSanitizer} from '@angular/platform-browser';
import {MdIconRegistry} from '@angular/material';


@Component({
    selector: 'app-root',
    template: `

    <md-toolbar color="primary" width="100%">
    <span> <img src="./assets/wf-logo.png" height="60" width="1360"/></span>
<div height="30"></div>
    </md-toolbar>
    <md-toolbar color="primary" width="100%">
    <span>
    <h1>Cornerstone Due-Diligence Dashboard</h1></span>

    </md-toolbar>


          <kendo-grid [kendoGridBinding]="gridData" [height]="550" [pageSize]="pageSize"
              [filterable]="true"
              [pageable]="true" [skip]="skip">
              <kendo-grid-column field="ecn" title="Main Party ECN ID" width="150">
              </kendo-grid-column>
              <kendo-grid-column field="wcisId" title="WCIS ID" width="120"  [filterable]="true">
              <ng-template kendoGridCellTemplate let-dataItem >
              <select *ngIf="dataItem.wcisResponselst?.length > 0" (change)="selectWcisId($event.target.value)">
                  <option>ECN   WCIS ID   LEGAL NAME<option disabled="true">
                  <option *ngFor="let c of dataItem.wcisResponselst" value="{{c.wcisId}}">{{c.ecnId}} {{c.wcisId}} {{c.legalName}}</option>
             </select>
              <div *ngIf="!(dataItem.wcisResponselst?.length > 0)">{{dataItem.wcisId}}</div>
              <!--input [readonly]="true" value="{{dataItem.wcisId}}" *ngIf="!(dataItem.wcisResponselst?.length > 0)" type="text"/-->
              </ng-template>

              </kendo-grid-column>
              <kendo-grid-column field="ecnForWcis" title="ECN ID for WCIS" width="120">
              </kendo-grid-column>
              <kendo-grid-column field="wcisStatus" title="WCIS Status" width="80">
              </kendo-grid-column>
              <kendo-grid-column field="ecnStatus" title="CRSTN Status" width="80">
              </kendo-grid-column>
              <kendo-grid-column field="Discontinued" title="Action" width="60">
              <ng-template kendoGridCellTemplate let-dataItem>
              <!--button md-raised-button *ngIf="dataItem.wcisResponselst?.length > 0">Submit</button-->
              <button md-fab><md-icon>save</md-icon></button>
              <!--md-icon>save-svg</md-icon-->
              </ng-template>
              </kendo-grid-column>
              <kendo-grid-column field="timeToLive" title="Time to Live" width="60">
              </kendo-grid-column>
             <div *kendoGridDetailTemplate="let dataItem">
              <!--kendo-grid [data]="dataItem.customerAccounts" [height]="100" [pageSize]="pageSize"/>
                  <kendo-grid-column field="{{dataItem.customerAccounts?.ecn}}" title="ECN" [width]="300"></kendo-grid-column>

              </kendo-grid-->

            <section *ngIf="dataItem.customerAccounts">
            <table class=".table-striped .table">
            <thead>
                  <tr>

                      <th style="width: 10%">
                        RP ECN ID
                      </th>
                      <th style="width: 20%">
                        RP  WCIS ID
                      </th>
                      <th style="width: 10%">
                        RP  ECN for WCIS
                      </th>
                      <th style="width: 20%">
                          Party Type
                      </th>
                      <th style="width: 20%">
                          WCIS Status
                      </th>
                      <th style="width: 20%">
                          Action
                      </th>

                  </tr>
              </thead>
              <tr *ngFor="let a of dataItem.customerAccounts">
              <th style="width: 10%">
                {{a.ecn}}
              </th>
              <th style="width: 20%">
                  {{a.companyId}}
              </th>
              <th style="width: 10%">
                  {{a.productId}}
              </th>
              <th style="width: 20%">
                  {{a.accountOpenDate}}
              </th>
              <th style="width: 20%">
                  {{a.accountNumber}}
              </th>
              <th style="width: 20%">


              </th>
              <th style="width: 10%">

              </th>
              </tr>
            <!--div *ngFor="let a of dataItem.customerAccounts">
              <p><strong>ECN:</strong> {{a.ecn}}</p>
              <p><strong>Company ID:</strong> {{a.companyId}}</p>
              <p><strong>Product ID:</strong> {{dataItem.customerAccounts?.productId}}</p>
              <p><strong>Open Date:</strong> {{dataItem.customerAccounts?.accountOpenDate}}</p>
              <p><strong>Account Number:</strong> {{dataItem.customerAccounts?.accountNumber}}</p>
              </div-->
            </table>
            </section>
              </div>
          </kendo-grid>


      `
})
export class AppComponent {
    //private gridData: GridDataResult;
    private pageSize: number = 10;
    private skip: number = 0;
    private data: Object[];
    //private items: any[] = customers;
    private gridData: any[] = customers;
    countries = [
       {id: 1, name: "United States"},
       {id: 2, name: "Australia"},
       {id: 3, name: "Canada"},
       {id: 4, name: "Brazil"},
       {id: 5, name: "England"}
     ];
    selectedValue = null;

    constructor(iconRegistry: MdIconRegistry, sanitizer: DomSanitizer) {
    iconRegistry.addSvgIcon(
        'save-svg',
        sanitizer.bypassSecurityTrustResourceUrl('assets/ic_save_black_24px.svg'));
  }
    public selectWcisId(wcisId){
      alert(wcisId);
      console.log("wcis" );
    }
    protected pageChange(event: PageChangeEvent): void {
        this.skip = event.skip;
      //  this.loadItems();
    }

  /**  private loadItems(): void {
        this.gridData = {
            data: this.items.slice(this.skip, this.skip + this.pageSize),
            total: this.items.length
        };
      //  alert(this.gridData.data[0]);
    }**/
}
