import { Component,NgModule, OnInit, ChangeDetectorRef} from '@angular/core';
//import { customers } from './customers';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import {DomSanitizer} from '@angular/platform-browser';
import {MdIconRegistry} from '@angular/material';
import {Http, Headers} from "@angular/http";
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';


@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['app.component.scss']



})
export class AppComponent implements OnInit {
    //private gridData: GridDataResult;
    private pageSize: number = 10;
    private skip: number = 0;
    //private data: Object[];
    public data: any[];

    //private items: any[] = customers;
    //private gridData: any[] = customers;
    private gridData: any[] = this.data;
    countries = [
       {id: 1, name: "United States"},
       {id: 2, name: "Australia"},
       {id: 3, name: "Canada"},
       {id: 4, name: "Brazil"},
       {id: 5, name: "England"}
     ];
    selectedValue = null;
    selectedState = null;

    constructor(iconRegistry: MdIconRegistry, sanitizer: DomSanitizer, private http: Http,
        private cd: ChangeDetectorRef) {
    iconRegistry.addSvgIcon(
        'save-svg',
        sanitizer.bypassSecurityTrustResourceUrl('assets/ic_save_black_24px.svg'));
  }
    public selectWcisId(wcisId){
      alert("wcisId "+wcisId.value);
      this.selectedValue = wcisId;
      console.log("wcis" );
    }
    protected pageChange(event: PageChangeEvent): void {
        this.skip = event.skip;
      //  this.loadItems();
    }
    ngOnInit(): void {
    //    this.http.get("./data.json")
      // const headers = new Headers();
      // headers.append('Access-Control-Allow-Origin', '*');
      // headers.append('Access-Control-Allow-Credentials', 'true');

      //this.http.get("http://112.32.4.99:9090/getCustomertarget")
      this.http.get('assets/data.json')
            .subscribe((gridData)=> {
                setTimeout(()=> {
                    this.gridData = gridData.json();
                }, 1000);
            });
    }
    //public updateWcisId(ecn: string){
    public updateWcisId(ecn: string){
        //alert("ecn "+ecn);
        let headers = new Headers();

        headers.append('Content-Type', 'application/json');
        let url = 'http://112.32.4.99:8082/updateCustomer?ecn='+ecn+'&wcisId='+this.selectedValue;
        //+ecn+'&wcisId='+this.selectedValue;
        //alert('url '+url);

        //this.http.post(url);

        this.http
             .post(url, {headers: headers}).subscribe();
            this.http.get("http://112.32.4.99:9090/getCustomertarget")
                   .subscribe((gridData)=> {
                       setTimeout(()=> {
                           this.gridData = gridData.json();
                       }, 1000);
                   });
        //     .map(res => res.json());
        //this.ngOnInit();
        //  parent.location.reload();
        this.cd.detectChanges();
    }

  /**  private loadItems(): void {
        this.gridData = {
            data: this.items.slice(this.skip, this.skip + this.pageSize),
            total: this.items.length
        };
      //  alert(this.gridData.data[0]);
    }**/

    public getStatusRowFormat(status)
    {
  //  alert(status);
	  var legendclass = "";
	  if(status.trim() == 'Select WCIS ID'){
		  legendclass+= "multiWcisRow";
    }
    else if(status.trim() == "ECN WCIS Mismatched"){
     legendclass+= "selectRow";
    }
    else if(status.trim() == "SUBMITTED to Cornerstone"){
     legendclass+= "submittedRow";
    }
    //alert(legendclass);
	  return legendclass;
  }
  public clientGridChange(clientGrid, selection){
      //alert("selection.index "+selection.index);
      let selectedClient = clientGrid.data.data[selection.index];


  }
}
