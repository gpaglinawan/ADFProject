﻿export const dummyData =[
{
	"Phase": "File Archival",
	"Revision":"102",
	"AuditType":"Test Audit",
	"ECN":"1234567",
	"ProcessStatus":"Completed",
	"Created":"08/25/2017",
	"AuditLog": [
		{"Narrative":"TestN1", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN2", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Warning"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN4", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Fatal"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"}
		]
},
{
	"Phase": "File Verifiation",
	"Revision":"123",
	"AuditType":"Test Audit",
	"ECN":"1234567",
	"ProcessStatus":"Completed",
	"Created":"08/25/2017",
	"AuditLog": [
		{"Narrative":"TestN1", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN2", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN4", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"}
		]
},
{
	"Phase": "File Validation",
	"Revision":"102",
	"AuditType":"Test Audit",
	"ECN":"1234567",
	"ProcessStatus":"Completed",
	"Created":"08/25/2017",
	"AuditLog": [
		{"Narrative":"TestN1", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN2", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN4", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"}
		]
},
{
	"Phase": "Transformation",
	"Revision":"102",
	"AuditType":"Test Audit",
	"ECN":"1234567",
	"ProcessStatus":"Completed",
	"Created":"08/25/2017",
	"AuditLog": [
		{"Narrative":"TestN1", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN2", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN4", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"}
		]
},
{
	"Phase": "WCIS Enrichment",
	"Revision":"102",
	"AuditType":"Test Audit",
	"ECN":"1234567",
	"ProcessStatus":"Completed",
	"Created":"08/25/2017",
	"AuditLog": [
		{"Narrative":"TestN1", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN2", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN4", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"}
		]
},
{
	"Phase": "DCEA Invoke",
	"Revision":"102",
	"AuditType":"Test Audit",
	"ECN":"1234567",
	"ProcessStatus":"Completed",
	"Created":"08/25/2017",
	"AuditLog": [
		{"Narrative":"TestN1", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN2", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN4", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"},
		{"Narrative":"TestN5", "fieldName": "TestF1", "ErrorDetails": "File Not Found", "ErrorType" : "Severe"}
		]
}
];
