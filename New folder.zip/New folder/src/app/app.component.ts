import { Component, OnInit } from '@angular/core';
import { process, State, filterBy, FilterDescriptor, CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { dummyData } from './products';
import {Http, Headers} from "@angular/http";
import {GridComponent, GridDataResult, DataStateChangeEvent, PageChangeEvent} from '@progress/kendo-angular-grid';
import {environment} from 'environments/environment';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {

     pageSize: number = 20;
     scrht: number = window.innerHeight/12;
     skip: number = 0;
    public checked: boolean = false;
	public filter: CompositeFilterDescriptor;
    public data: any[];
    environmentName = environment.envName;
    environmentHost = environment.enviHost;
    environmentPort = environment.enviPort;
     gridData: any[] = this.data;
	 headerGridData: any[] = this.data;
	 detailGridData: any[] = this.data;

	 mainHeaderStatus: any[] = this.data;
	childDataRevisionWise={};
	childDataRevisionWiseError={};
  selectedValue = null;

  public clear_state: State = {
      filter:  {
        logic: 'and',
        filters: [
              { field: "ecnId", operator: "isnotnull"},
              { field: "processStatus.processStatusName", operator: "contains", value:""}

        ]
    }

  };

public custArray:Array<any> = [];
detailGridData1: GridDataResult;


  constructor(private http: Http) {
  }

  public isShowStatus(dataItem:any, index: number): boolean{
	 //debugger
	  return dataItem.statusData!=null && dataItem.statusData.length>0;
  }
	 public isShowAuditLog(dataItem:any, index: number): boolean{
	// debugger
	  return dataItem.auditLogs!=null && dataItem.auditLogs.length>0;
  }
    protected pageChange(event: PageChangeEvent): void {
        this.skip = event.skip;
      //  this.loadItems();
    }


mainGridOptions (): void{
	alert("in mainGridOptions ");
}
public chandleChange(data, dataItem, columns){
	alert("in mainGridOptions ");
}
gridUserSelectionChange(gridUser, selection) {

	//debugger;
    // var selectedData = gridUser.data.data[selection.index];
	//alert(selection.selectedRows[0].dataItem.revision);

	this.detailGridData=this.childDataRevisionWise[selection.selectedRows[0].dataItem.revision];

  this.detailGridData = filterBy(this.detailGridData, {
    logic: 'and',
    filters: [
          { field: "ecnId", operator: "isnotnull"},
          { field: "processStatus.processStatusName", operator: "isnotnull"},

    ]
});

     //console.log(selectedData);
 }


  ngOnInit(): void {
      //this.http.get("http://"+this+:9090/getAudit")
      //alert("http://"+this.environmentHost+":"+this.environmentPort+"/getAudit");
      //this.http.get("http://wuvra00a0263:9090/getAudit")
      this.http.get("http://"+this.environmentHost+":"+this.environmentPort+"/getAudit")
            .subscribe((gridData)=> {
                setTimeout(()=> {

					var fileName = ["hogancis_cstn_cuac.dat.txt", "hogancis_cstn_cucu.dat.txt", "hogancis_cstn_cust.dat.txt"];
					var response=gridData.json();
					var lheaderGridData=[];
					var ldetailGridData=[];
					var lmainHeaderStatus=[];
					var totalRevision=[];
					var revisonJsontemp={};
					var statusData=[];
					var lchildataRevisonwise={};
					var lchildDataRevisionWiseError={};

					for(var i=0;i<response.length;i++)
						{
							var curJson=response[i];
							if(curJson!=null && curJson.hasOwnProperty('phase') && curJson.phase.hasOwnProperty('phsName'))
							{
								if(curJson.phase.phsName == "FILE_ARCHIVAL" || curJson.phase.phsName=="FILE_VERFIFICATION")
								{
									//debugger;
									lheaderGridData.push(curJson);
									var errorString='';
									var isError=false;
									if(curJson.auditLogs.length>0){
										//debugger;
											if(curJson.auditLogs[0].hasOwnProperty('errorDetails') && curJson.auditLogs[0].errorDetails.hasOwnProperty('errorId') ){
												errorString=curJson.auditLogs[0]['narrative'];
												isError=true;
											}
										}
									if(totalRevision.indexOf(curJson.revision)==-1){
										totalRevision.push(curJson.revision);
										var revisonJson={};
										revisonJson['revision']=curJson.revision;
										revisonJson['dateTimeCreated']=curJson.dateTimeCreated;
										revisonJson['isError']=isError;
										statusData=[];

										if(errorString.indexOf("ISSUE: Record count discrepancy between Control(Header) and HOGAN Data file")>=0){
													var jsonStatusData={};

													jsonStatusData['fileName']='Control';
													jsonStatusData['phase']=curJson.phase.phsName;
													jsonStatusData['dateTimeCreated']=curJson.dateTimeCreated;
													jsonStatusData['error']=errorString;
													jsonStatusData['status']=curJson.processStatus.processStatusName;
													if(isError){
															statusData.push(jsonStatusData);
													}
										}


										/*** If File level  Error not at control file **/
													var jsonStatusData={};

													jsonStatusData['fileName']=fileName[0];
													jsonStatusData['phase']=curJson.phase.phsName;
													jsonStatusData['dateTimeCreated']=curJson.dateTimeCreated;
													jsonStatusData['error']=errorString;
													jsonStatusData['status']=curJson.processStatus.processStatusName;
													if(isError){
														if( errorString.indexOf(fileName[0]) != -1)
															statusData.push(jsonStatusData);
													}else{
														statusData.push(jsonStatusData);
													}

													jsonStatusData={};
													jsonStatusData['fileName']=fileName[1];
													jsonStatusData['dateTimeCreated']=curJson.dateTimeCreated;
													jsonStatusData['phase']=curJson.phase.phsName;
													jsonStatusData['status']=curJson.processStatus.processStatusName;
													jsonStatusData['error']=errorString;
													if(isError){
														if( errorString.indexOf(fileName[1]) != -1)
															statusData.push(jsonStatusData);
													}else{
														statusData.push(jsonStatusData);
													}

													jsonStatusData={};
													jsonStatusData['fileName']=fileName[2];
													jsonStatusData['phase']=curJson.phase.phsName;
													jsonStatusData['dateTimeCreated']=curJson.dateTimeCreated;
													jsonStatusData['error']=errorString;
													jsonStatusData['status']=curJson.processStatus.processStatusName;
													if(isError){
														if( errorString.indexOf(fileName[2]) != -1)
															statusData.push(jsonStatusData);
													}else{
														statusData.push(jsonStatusData);
													}


										revisonJson['statusData']=statusData;
										revisonJsontemp[revisonJson['revision']]=revisonJson;
										lmainHeaderStatus.push(revisonJson);
									}else{
										var existinData=revisonJsontemp[curJson.revision];
										if(existinData['isError']==false){
											existinData['isError']=isError;
										}
										statusData=existinData['statusData'];
										var jsonStatusData={};
										jsonStatusData['fileName']=fileName[0];
										jsonStatusData['dateTimeCreated']=curJson.dateTimeCreated;
										jsonStatusData['phase']=curJson.phase.phsName;
										jsonStatusData['status']=curJson.processStatus.processStatusName;
										if(existinData['isError']==false)
											jsonStatusData['error']=errorString;
										if(isError){
											if( errorString.indexOf(fileName[0]) != -1)
												statusData.push(jsonStatusData);
										}else{
											statusData.push(jsonStatusData);
										}

										jsonStatusData={};
										jsonStatusData['fileName']=fileName[1];
										jsonStatusData['dateTimeCreated']=curJson.dateTimeCreated;
										jsonStatusData['phase']=curJson.phase.phsName;
										if(existinData['isError']==false)
											jsonStatusData['error']=errorString;
										jsonStatusData['status']=curJson.processStatus.processStatusName;
										if(isError){
											if( errorString.indexOf(fileName[1]) != -1)
												statusData.push(jsonStatusData);
										}else{
											statusData.push(jsonStatusData);
										}
										jsonStatusData={};
										jsonStatusData['fileName']=fileName[2];
										jsonStatusData['dateTimeCreated']=curJson.dateTimeCreated;
										jsonStatusData['phase']=curJson.phase.phsName;
										if(existinData['isError']==false)
											jsonStatusData['error']=errorString;
										jsonStatusData['status']=curJson.processStatus.processStatusName;
										if(isError){
											if( errorString.indexOf(fileName[2]) != -1)
												statusData.push(jsonStatusData);
										}else{
											statusData.push(jsonStatusData);
										}
										existinData['statusData']=statusData;
									}
								}
								else{
									//debugger
									var childArray=[];
									if(lchildDataRevisionWiseError.hasOwnProperty(curJson['revision']) != true ) {
										//debugger;
										if(curJson.hasOwnProperty('auditLogs')&& curJson.auditLogs.length > 0 ){
											lchildDataRevisionWiseError[curJson['revision']]=true;
										}else{
											lchildDataRevisionWiseError[curJson['revision']]=false;
										}
									}
									else{

										if(lchildDataRevisionWiseError[curJson['revision']]!=true  ){
											if(curJson.hasOwnProperty('auditLogs') && curJson.auditLogs.length > 0 ){
												lchildDataRevisionWiseError[curJson['revision']]=true;
										}else{
											lchildDataRevisionWiseError[curJson['revision']]=false;
											}
										}
									}


									if(this.childDataRevisionWise.hasOwnProperty(curJson['revision'])  ){
										childArray=this.childDataRevisionWise[curJson['revision']];
										childArray.push(curJson);
										this.childDataRevisionWise[curJson['revision']]=childArray;
									}else{
										childArray=[];
										childArray.push(curJson);
										this.childDataRevisionWise[curJson['revision']]=childArray;
									}
									ldetailGridData.push(curJson);
								}
							}
						}
					//debugger;
					this.childDataRevisionWiseError=lchildDataRevisionWiseError;
					this.headerGridData=lheaderGridData;
					this.detailGridData=ldetailGridData;
          this.custArray =ldetailGridData;
          this.detailGridData1= process(this.custArray, this.clear_state);
                    this.gridData = gridData.json();
					this.mainHeaderStatus=lmainHeaderStatus;

                    this.gridData = gridData.json();
                }, 1000);
            });
    }

   public getLegendColor(data)
  {
	  debugger;
	  var legendclass = "legend ";
	  if(data.isError == true)
		  legendclass+= "Red";
	  else if(this.childDataRevisionWiseError[data.revision] ==true){
		  legendclass+= "Yellow";
	  }else
		  legendclass+= "Green";

	  return legendclass;
  }
   public getLegendColorDetails(isError)
  {
	 // debugger;
	  var legendclass = "legend ";
	  if(isError != null)
		  legendclass+= "Red";
	  else
		  legendclass+= "Green";

	  return legendclass;
  }
  public getErrorRowFormat(isError)
  {
	//  debugger;
	 // alert(isError);
	  var legendclass = "";
	  if(isError == "ERROR")
		  legendclass+= "ErrorRow";

	  return legendclass;
  }

 }
