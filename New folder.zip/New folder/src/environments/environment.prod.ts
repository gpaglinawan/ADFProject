export const environment = {
  production: true,
  envName: 'prod',
  enviHost: 'wuvra00a0263',
  enviPort: '9090'
};
