import { Directive, OnInit, OnDestroy } from '@angular/core';
import { DataBindingDirective, GridComponent } from '@progress/kendo-angular-grid';
@Directive({
   selector: '[gridUser]'
})
export class ProductsBindingDirective extends DataBindingDirective {
   constructor(grid: GridComponent) {
       super(grid);
       //alert ('usersGrid '+grid);
       //debugger;
   }
}
