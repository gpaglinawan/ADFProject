import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GridModule } from '@progress/kendo-angular-grid';
import { AppComponent } from './app.component';
import { HttpModule } from "@angular/http";
import { ProductsBindingDirective }   from './customers.directives';
import {MdButtonModule, MdCheckboxModule, MdSelectModule, MdInputModule,MdToolbarModule, MdIconModule} from '@angular/material';
import { FormsModule } from '@angular/forms';
import { Ng2DeviceDetectorModule } from 'ng2-device-detector';

@NgModule({
  declarations: [
    AppComponent,ProductsBindingDirective
  ],
  imports: [
    BrowserModule, BrowserAnimationsModule, GridModule, MdToolbarModule, HttpModule, Ng2DeviceDetectorModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
