export const environment = {
  production: true,
  envName: 'uat',
  enviHost: 'wuvra00a0264',
  enviPort: '9090'
};
