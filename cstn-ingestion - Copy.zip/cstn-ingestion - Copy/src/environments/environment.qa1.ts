export const environment = {
  production: true,
  envName: 'qa1',
  enviHost: 'wsvra98a0724',
  enviPort: '9090'
};
