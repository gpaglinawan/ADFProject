export const environment = {
  production: true,
  envName: 'uat1',
  enviHost: 'wuvra98a0724',
  enviPort: '9090'
};
