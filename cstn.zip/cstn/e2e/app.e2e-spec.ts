import { CstnPage } from './app.po';

describe('cstn App', () => {
  let page: CstnPage;

  beforeEach(() => {
    page = new CstnPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
